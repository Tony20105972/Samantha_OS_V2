
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

class Agent(BaseModel):
    id: int
    name: str
    description: str
    creator: str

fake_agents = [
    {"id": 1, "name": "TextCleaner", "description": "Cleans text data", "creator": "Alice"},
    {"id": 2, "name": "Translator", "description": "Translates text to various languages", "creator": "Bob"},
]

@router.get("/agents")
def list_agents():
    return fake_agents

@router.get("/agent/{agent_id}")
def get_agent(agent_id: int):
    agent = next((a for a in fake_agents if a["id"] == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent

@router.post("/agent/{agent_id}/buy")
def buy_agent(agent_id: int):
    return {"status": "pending", "message": "Payment system coming soon!"}
