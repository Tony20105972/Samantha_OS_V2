
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

class Proposal(BaseModel):
    id: int
    title: str
    description: str
    proposer: str

fake_proposals = [
    {"id": 1, "title": "Add new agent type", "description": "Add image captioning agent", "proposer": "0x123..."},
    {"id": 2, "title": "Reduce inference cost", "description": "Lower token fee for simple agents", "proposer": "0xabc..."},
]

@router.get("/dao/proposals")
def list_proposals():
    return fake_proposals

@router.get("/dao/proposal/{proposal_id}")
def get_proposal(proposal_id: int):
    prop = next((p for p in fake_proposals if p["id"] == proposal_id), None)
    if not prop:
        raise HTTPException(status_code=404, detail="Proposal not found")
    return prop

@router.post("/dao/vote")
def vote_proposal(address: str, proposal_id: int, vote: str):
    return {
        "status": "recorded",
        "message": "Vote logged. Real voting coming with smart contract support!"
    }
